1-
Execute MyMailboxISE.ps1 under PowerShel ISE


2- 
Copy the mmb.bat in any place, do not forget to edit the folder 
"C:\users\bd\desktop\mmb\MyMailbox.ps1" to suit you
In my case mmb is on my Desktop

Double Click on mmb.bat = Execution of MyMailBox.ps1 unde PowerShell Console


Any Question :)
Any Error :)
Anything :)

Your Feedback will encourage me to continue......